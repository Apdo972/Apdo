document.getElementById("fitnessForm").addEventListener("submit", function(e) {

    e.preventDefault();

    const name = document.getElementById("name").value.trim();

    const age = parseInt(document.getElementById("age").value);

    const level = document.getElementById("level").value;

    let workout = "";

    let nutrition = "";

    let water = "";

    // تمارين حسب المستوى

    switch(level) {

        case "beginner":

            workout = "Workout: Start with light cardio (walking, cycling) 3x/week + bodyweight exercises like squats and push-ups.";

            nutrition = "Nutrition: Eat balanced meals with more protein, fruits, and vegetables. Avoid junk food.";

            break;

        case "intermediate":

            workout = "Workout: Do strength training + cardio 4-5x/week. Include HIIT or circuits.";

            nutrition = "Nutrition: Eat high-protein meals, healthy carbs (like oats, rice), and good fats (nuts, olive oil).";

            break;

        case "advanced":

            workout = "Workout: Follow a structured plan (push/pull/legs), strength training 5-6x/week, with HIIT or steady cardio.";

            nutrition = "Nutrition: Track macros, meal prep, focus on lean proteins and complex carbs.";

            break;

        default:

            workout = "Please select a valid level.";

    }

    // حساب المياه حسب العمر

    if (age < 18) {

        water = "Water: Drink at least 1.5 to 2 liters of water daily.";

    } else if (age <= 50) {

        water = "Water: You need about 2.5 to 3 liters of water per day.";

    } else {

        water = "Water: Try to drink 2 to 2.5 liters of water daily.";

    }

    // عرض النتيجة

    document.getElementById("greeting").textContent = `Hello ${name}, here's your personalized plan:`;

    document.getElementById("workout").textContent = workout;

    document.getElementById("nutrition").textContent = nutrition;

    document.getElementById("water").textContent = water;

    document.getElementById("result").style.display = "block";

});